<?php

require '../scripts/config.php';

if(isset($_POST["token"]) and !isset($_POST["submitf"])){
	require './connect/crypto.php';

    	 
	$pword = password_hash($_POST['pword'], PASSWORD_DEFAULT); 
    $token =  $_POST['token'];
	
	    if($token == "") die("This link has already been used");
		  $raw_data = decrypt($token);
		  $data = explode("___", $raw_data); 
		  //$timec."___".$email."___".$username."___".$timec
		  $timec = $data[0]; 
		  if($data[0] != $data[3]) die("");
		  if((time() - $timec) > 7200) die("Sorry! This link has expired");
		  
		  
		   $pdo = new mypdo2();
		  $pdo->get_recover($timec, $data[1]);
		     
		  $pdo->delete_recover($timec, $data[1]);
		  
		  $pdo->update_password($pword, $data[1]);
          
		   die("PASS");  

 
			  }
             

     
elseif(isset($_REQUEST["pl"]) and !isset($_POST["submitf"])){
              
			 require'connect/crypto.php';
			 $raw_data = decrypt($_REQUEST["pl"]);
		     $data = explode("___", $raw_data); 
			 $username =	$data[2];	 
             html_out($_REQUEST["pl"], $username); }


function html_out($token, $username){?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title> Reset Password </title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  
  
  
<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="css/fontastic.css">
    <!-- Google fonts - Roboto -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
    <!-- jQuery Circle-->
    <link rel="stylesheet" href="css/grasp_mobile_progress_circle-1.0.0.min.css">
    <!-- Custom Scrollbar-->
    <link rel="stylesheet" href="vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.ico">
  <link rel="stylesheet" href="./css/bootstrap.min.css">
<link rel="stylesheet" href="./css/font-awesome.min.css">
<link rel="stylesheet" href="./css/styleme.css">
<link href="./css/magnific-popup.css" rel="stylesheet">
<link href="./css/select2.min.css" rel="stylesheet">



  <!-- =======================================================
    Theme Name: Regna
    Theme URL: https://bootstrapmade.com/regna-bootstrap-onepage-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
</head>

<body style="background-color:#F5F5F5; text-align:center">

<div class=""  style="width:100%; max-width:600px; display:inline-block; background-color:#FFF">
            <img src="../img/logo.webp" style="max-width:100%; border-radius:0px;">

<div style="margin:20px;"><a href="./"> Login </a></div>

  <main id="main" style="margin-top:40px; margin-bottom:60px; padding:10px;">



<h3>Enter your new password details below</h3>

<div>  <!--:::::::::::      Beginning of form div  :::::::::::-->
<div style="color:#F00;" id="recovery_report"></div>
<form onsubmit="password_change_form(event)">
<div class="row" style="text-align:center">
<div class="col-12 col-md-6">
<div class=" form-group"><label>New Password </label><br /><input class="form-control" id="pword1" required placeholder="*******" type="password" /></div></div>
<div class="col-12 col-md-6">
<div class=" form-group"><label>Retype Password </label><br /><input class="form-control" id="pword2" required placeholder="*******" type="password"/></div></div>
<div class=" col-12"  style="width:100%; text-align:center; margin-top:20px;"><input type="hidden" id="token" value="<?php echo $token; ?>" /><input type="hidden" id="username" value="<?php echo $username; ?>" /><button class="btn btn-primary"> Reset </button></div>
</div>
</form>
</div>  <!--:::::::::::      End of form div  :::::::::::-->


  </main>


</div>

<!--==========================
    Footer
  ============================-->

  


  

  <!-- JavaScript Libraries -->
 <script src="vendor/jquery/jquery.min.js?version=<?php echo glob_version; ?>"></script>
    <script src="vendor/popper.js/umd/popper.min.js?version=<?php echo glob_version; ?>"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js?version=<?php echo glob_version; ?>"></script>
<script src="js/main.js?version=<?php echo glob_version; ?>"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js?version=<?php echo glob_version; ?>"></script>
    <script src="vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js?version=<?php echo glob_version; ?>"></script>
    <!-- Main File-->
    <script src="js/front.js?version=<?php echo glob_version; ?>"></script>
    <script src="js/signing.js?version=<?php echo glob_version; ?>"></script>
   
  
</body>
</html>

<?php }



class mypdo2{
	 public $pdc = null;
	 public function __construct(){
		 $host = dbhost;
		 $db   =  dbname;
		 $user  =  dbuser;
		 $pass  =   dbpass;
		 $charset = 'utf8mb4';
		 $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
		 $opt = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false,];
		 $this->pdc = new PDO($dsn, $user, $pass, $opt);
		 }
	 
	 
	 
	 public function get_recover($timec, $username){
		 $qry = "SELECT username FROM recovertb WHERE id = ? AND username = ?";
		 $stmt = $this->pdc->prepare($qry);
		 $stmt->bindParam(1, $timec, PDO::PARAM_INT);
		 $stmt->bindParam(2, $username, PDO::PARAM_STR); 
		 $stmt->execute();
		 if($stmt->rowCount() < 1)
		 die('link has expired');
		 else{
		  return $stmt->fetch();
		    }
		    
		 }
	  
	  public function delete_recover($timec, $username){
		 $qry = "DELETE FROM recovertb WHERE id = ? AND username = ?";
		 $stmt = $this->pdc->prepare($qry);
		 $stmt->bindParam(1, $timec, PDO::PARAM_INT);
		 $stmt->bindParam(2, $username, PDO::PARAM_STR); 
		 $stmt->execute();
		 }
	   
	   
	   public function update_password($pword, $username){
		 $qry = "UPDATE admins SET password = ? WHERE email = ?";
		 $stmt = $this->pdc->prepare($qry);
		 $stmt->bindParam(1, $pword, PDO::PARAM_STR);
		 $stmt->bindParam(2, $username, PDO::PARAM_STR); 
		 $stmt->execute();
		  }
	 }
















