// JavaScript Document


if($("#myTable").length){

	table = $("#myTable").DataTable({
	  "processing": true,
	  "serverSide": true,
	  ajax: "./connect/post.php?ch=get_posts",
	  bSortCellsTop: true,
	  rowId: 0,
	  dom: '<B<"datatable_dom_pull_left"f><"pull-right"l>r<t>lip>',
	  lengthMenu: [
		[60, 100, 200, -1],
		[60, 100, 200, "All"],
	  ],
	  columns: [
		{
		  data: null,
		  sortable: false,
		  render: function (data, type, row, meta) {
			return meta.row + meta.settings._iDisplayStart + 1}
		},
		{ data: 1 },
		{ data: 2},
		{ data: 3},
		{ data: 4},
		{ data: null, className: 'uarea', searchable:false, sortable:false, render:function(a,b,c){  return '<a target="_blank" href="edit-post.php?p_id='+c[0]+'" class="fa fa-edit"></a>';} },
	  ],
	  order: [[1, "desc"]],
	  select: true,
	  select: {
		style: "os",
		selector: "td:first-child",
	  },
	  buttons: [
		{
			text: "New Post",
			action: function(){
				window.location.href = "new-post.php";
			}
		},
		"csv",
		{ extend: "colvis", collectionLayout: "fixed three-column" },
	  ],
	});
	
	$("#myTable thead tr:eq(1) th").each(function (i) {
		if ($(this).hasClass("sch")) {
		  $(this).html('<input type="text" placeholder="search"/>');
		  $("input", this).on("keyup change", function () {
			if (table.column(i).search() !== this.value) {
			  table.column(i).search(this.value).draw();
			}
		  });
		} else if ($(this).hasClass("sch_sel")) {
		  $("select", this).on("change", function () {
			if (table.column(i).search() !== this.value) {
			  table.column(i).search(this.value).draw();
			}
		  });
		}
	  });
	
	}
	
	 



$(document).ready(function(){
	
	CKEDITOR.config.height = 500;
	CKEDITOR.config.width = 'auto';
	 
	 CKEDITOR.replace('desc_n');


 });
 
 
 
 function  submit_form(event){
	 
	 event.preventDefault();
	 
	 $("#r_msg").html('');
	 
	 var desc_n = CKEDITOR.instances['desc_n'].getData();


	 
	if(desc_n.length < 10) { alert('Please provide a Blog Post in French version'); return;}
	 
	 
	 var title = $("#title").val().trim();
	 var keywords = $("#keywords").val().trim();
	 var meta = $("#meta").val().trim();

	 
	 
	 var fdata = {ch: 'new_post', title, keywords, meta,  desc_n};
	 
	 var sbnx = $("#sbutton").html();
	 $("#sbutton").html('<span class="fa fa-spin fa-spinner fa-2x"></span> Submitting...');
	 $.ajax({
	  type: "POST",
	  url:   "./connect/post.php",
	  data: fdata,
	  success: function(data){ //console.log(data);
			  $("#sbutton").html(sbnx);
			 if(data == 'success'){
				myalert('<div class="alert alert-success"><span class="fa fa-check-circle-o"></span>  post created  Successfully </div>');
				setTimeout(function(){window.location.href = "./blog.php"}, 1500)
			 }
			 else{
				 myalert('<div class="alert alert-danger"> '+data+' </div>');
			 }
			 
	  }
		});
	 
 }



  
 function  submit_form2(event){
	 
	event.preventDefault();
	
	$("#r_msg").html('');
	
	var desc_n = CKEDITOR.instances['desc_n'].getData();
	
	if(desc_n.length < 10) { alert('Please provide a proper message'); return;}
	
	
	var p_id = $("#p_id").val().trim();
	var title = $("#title").val().trim();
	var keywords = $("#keywords").val().trim();
	var meta = $("#meta").val().trim();
	
	
	var fdata = {ch: 'edit_post', p_id, title, keywords, meta, desc_n};
	
	var sbnx = $("#sbutton").html();
	$("#sbutton").html('<span class="fa fa-spin fa-spinner fa-2x"></span> Submitting...');
	$.ajax({
	 type: "POST",
	 url:   "./connect/post.php",
	 data: fdata,
	 success: function(data){ //console.log(data);
			 $("#sbutton").html(sbnx);
			if(data == 'success'){
				myalert('<div class="alert alert-success"><span class="fa fa-check-circle-o"></span>  Updated Successfully </div>');
			}
			else{
				myalert('<div class="alert alert-danger"> '+data+' </div>');
			}
			
	 }
	   });
	
	
}



function remove_post(event, np) {
	event.preventDefault();
	  if (np == 0) {
		$("#modal_delete .modal-body").html("Do you want to delete this post?");
		$("#modal_delete .delete_action_btn")[0].setAttribute(
		  "onClick",
		  "remove_post(event, 1)"
		);
		$("#modal_delete .delete_action_btn").removeClass("btn-success");
		$("#modal_delete .delete_action_btn").addClass("btn-danger");
		$("#modal_delete .delete_action_btn").html(
		  '<span class="fa fa-trash-o"></span>  Delete'
		);
		$("#modal_delete").modal("show");
	
		$("#delete_conf_code").html(random_string(8));
		$("#delete_conf_code_val").val("");
	  } else {
		if ($("#delete_conf_code").html() != $("#delete_conf_code_val").val()) {
		  myalert("wrong code provided.");
		  return;
		}
		var p_id = $("#p_id").val().trim();

		fdata = { ch: "delete_post",  p_id };
	
		var sbutton = $("#rsubmit").html();
	
		$("#rsubmit").html(
		  '<span class="fa fa-spin fa-spinner"></span>'
		);
	
		$.ajax({
		  type: "POST",
		  url: "./connect/post.php",
		  data: fdata,
		  success: function (data) {
			console.log(data);
			data = data.trim();
			$("#rsubmit").html("");
			if (data.substr(0, 4) == "PASS") {
			    
				$("#rsubmit").html("");
				$("#post_form").html("");
				myalert('<div class="alert alert-success"><span class="fa fa-check-circle-o"></span>  Post has been removed </div>');
			
			} else {
				$("#rsubmit").html(sbutton);
				myalert('<div class="alert alert-danger"> '+data+' </div>');
			}
		  },
		});
	  }
	}
	

	function random_string(length) {
		var result           = '';
		var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
		var charactersLength = characters.length;
		for ( var i = 0; i < length; i++ ) {
		  result += characters.charAt(Math.floor(Math.random() * 
	 charactersLength));
	   }
	   return result;
	}
	





	