
var editor = new $.fn.dataTable.Editor( {
    ajax:  './connect/edit_contact.php',
    table: '#myTable',
	idSrc:  0,
    fields: [
		//{ label: 'Project',  name: 0, type : 'select', options: project_ray,   },
        // { label: 'First Name',  name: 1  },
		// { label: 'Last Name',  name: 2, },
		// { label: 'Email Address',  name: 3  },
		
    ],
	formOpttions: {
		inline: {
			//onBlur: 'submit'
			}
		}
} );




// JavaScript Document
var table = null;
  


table = $('#myTable').DataTable( {
	"processing": true,
	"serverSide": true,
   "ajax": "./connect/get_data.php?table=contacts",
   "bSortCellsTop" : true,
    dom: '<B<"datatable_dom_pull_left"f><"pull-right"l>r<t>lip>',
	'lengthMenu': [[60, 100, 200, -1], [60, 100, 200, 'All']],
    columns: [
        { data: null, sortable: false,  render: function(data, type, row, meta){ return meta.row + meta.settings._iDisplayStart + 1;}},
		{ data: 1 },
		{ data: 2 },
		{ data: 3 },
		{ data: 4 },
		// etc
    ], 
	"order" : [[1, "asc"]],
    select: true,
	select: {
		style: 'os',
		selector: 'td:first-child'
		},  
    buttons: [
		{ extend: 'remove', editor: editor },
		'csv'
    ]
} );




$('#myTable thead tr:eq(1) th').each( function (i) {
        
		 if($(this).hasClass('sch')){
			 $(this).html('<input type="text" placeholder="search"/>')
			 $('input', this).on('keyup change', function(){
				if ( table.column(i).search() !== this.value ) {
					
					
					table
						.column(i)
						.search( this.value )
						.draw();
				}
			} );
		 }
		 else if($(this).hasClass('sch_sel')){
			 $(this).html('<select><option value=""></option><option value="0">Unpaid</option><option value="1">Paid</option></select>')
			 $('select', this).on('change', function(){
				if ( table.column(i).search() !== this.value ) {
					
					
					table
						.column(i)
						.search( this.value )
						.draw();
				}
			} );
		 }
});


