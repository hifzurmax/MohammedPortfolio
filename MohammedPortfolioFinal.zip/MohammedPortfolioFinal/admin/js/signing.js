// JavaScript Document


//////////////////////////////////////////////////////////////////////////////////


function sign_in(event){ 
	
event.preventDefault();

var username = $("#username").val().trim();
var password = $("#password").val().trim();

if(password.length < 6) return;	

 if(!(/^[^\s()<>@,;:\/]+@\w[\w\.-]+\.[a-z]{2,}$/.test(username))) return;

var fdata = {ch : 'sign_in', email : username,  password : password} ;
	
var sbutton = $("#sbutton").html(); //grab the initial content
$("#errmsg").html('');  

$("#sbutton").html('<span class="fa fa-spin fa-spinner fa-2x"></span> please wait...');
$('.card-footer').hide();
   
   $.ajax({
	 type: "POST",
	 url:   "./connect/signing.php",
	 data: fdata,
	 success: function(data){ //console.log(data);
		     //dommie('2', '');
		     if(data == 'success'){
				//  $("#sbutton").html('<span class="fa fa-sign-in text-success">Signing in .....</span>');
                //   $("form").trigger('reset');
				//   $("#2fax").slideUp(500, function(){$("#2fa").slideDown()});
				$("#sbutton2").html('<span class="fa fa-sign-in text-success">Signing in .....</span>');
				$("form").trigger('reset');
				window.location.replace("./");
			  }
			  else{
				$("#sbutton").html(sbutton);
                $('.card-footer').show(); 
				$("#errmsg").html(data);
				var elmnt = document.getElementById("errmsg");
                 elmnt.scrollIntoView();
				
			  }
		    },
		  });	

}


function sign_in2(event){ 
	
	event.preventDefault();
	
	var code = $("#code").val().trim();
	
	
	var fdata = {ch : 'sign_in2', code} ;
		
	var sbutton = $("#sbutton2").html(); //grab the initial content
	$("#errmsg2").html('');  
	
	$("#sbutton2").html('<span class="fa fa-spin fa-spinner fa-2x"></span> please wait...');
	$('.card-footer').hide();
	   
	   $.ajax({
		 type: "POST",
		 url:   "./connect/signing.php",
		 data: fdata,
		 success: function(data){ //console.log(data);
				 //dommie('2', '');
				 if(data == 'success'){
					 $("#sbutton2").html('<span class="fa fa-sign-in text-success">Signing in .....</span>');
					 //$('button').prop('disabled', false);
					  $("form").trigger('reset');
					  window.location.replace("./");
				  }
				  else{
					$("#sbutton2").html(sbutton);
					$('.card-footer').show(); 
					$("#errmsg2").html(data);
					var elmnt = document.getElementById("errmsg");
					 elmnt.scrollIntoView();
					
				  }
				},
			  });	
	
	}
	


function sign_up(event){
	
event.preventDefault();

var username = $("#username").val().trim();
var password = $("#password").val().trim();
var fname = $("#fname").val().trim();

if(password.length < 6) return;	
if(fname.length < 3) return;	

 if(!(/^[^\s()<>@,;:\/]+@\w[\w\.-]+\.[a-z]{2,}$/.test(username))) return;

var fdata = JSON.stringify({'uid' : 'web', 'ch' : 'sign_up', 'data' : {'email' : username, 'fname' : fname,  'password' : password}}) ;
	
var sbutton = $("#sbutton").html(); //grab the initial content
$("#errmsg").html('');

$("#sbutton").html('<span class="fa fa-spin fa-spinner fa-2x"></span> please wait...');
$('.card-footer').hide();
   
   $.ajax({
	 type: "POST",
	 url:   "./connect/signing.php",
	 data: fdata,
	 dataType: "json",
	 contentType: "application/json",
	 success: function(data){ //console.log(data);
		     //dommie('2', '');
		     if(data['status'] == 'success'){
				 $("#sbutton").html('<span style="font-size:14px;" class="text-success">Registration Successful. <small>(Note: You might not be able to login now till your account is approve)</small></span>');
                 //$('button').prop('disabled', false);
				  $("form").trigger('reset');
				   }
			  else{
				$("#sbutton").html(sbutton);
                $('.card-footer').show(); 
				$("#errmsg").html(data['message']);
				var elmnt = document.getElementById("errmsg");
                 elmnt.scrollIntoView();
				
			  }
		    },
		  });	

}



function forgot_pw(event){
	
event.preventDefault();

var username = $("#username").val().trim();

 if(!(/^[^\s()<>@,;:\/]+@\w[\w\.-]+\.[a-z]{2,}$/.test(username))) return;

var fdata = {'ch' : 'forgot_pw', 'email' : username} ;
	
var sbutton = $("#sbutton").html(); //grab the initial content
$("#errmsg").html('');

$("#sbutton").html('<span class="fa fa-spin fa-spinner fa-2x"></span> please wait...');
$('.card-footer').hide();
   
   $.ajax({
	 type: "POST",
	 url:   "./connect/signing.php",
	 data: fdata,
	 success: function(data){ //console.log(data);
		     //dommie('2', '');
		     if(data == 'success'){
				 $("#sbutton").html('<span style="font-size:14px;" class="text-success"> A Password recovery link has been sent to your email address. Please check your email inbox or spam folder to recover your password</span>');
                 //$('button').prop('disabled', false);
				  //$("form").trigger('reset');
				   }
			  else{
				$("#sbutton").html(sbutton);
                $('.card-footer').show(); 
				$("#errmsg").html(data);
				var elmnt = document.getElementById("errmsg");
                 elmnt.scrollIntoView();
				
			  }
		    },
		  });	

}



$(document).ready(function() {
$(".close_mag").click(function(){ $.magnificPopup.close(); });
});


function myalert(messagez){
	//alert("jjjiii");
	
$.magnificPopup.close();

setTimeout(function(){
$.magnificPopup.open({
  items: {
    src: '<div style="width:100%; text-align:center" class="white-popup"><div style="width:auto; max-width:500px; display:inline-block; background-color:#EEE; text-align:left; padding:20px; color: #000">' + messagez + '</div></div>', // can be a HTML string, jQuery object, or CSS selector
    type: 'inline'
  }
}); }, 500);
	}
	

function dommie(vasz, str){ 
	if(vasz == "1"){
$.magnificPopup.open({
  items: {
    src: '<div style="width:100%; text-align:center" class="white-popup"><div style="width:auto; max-width:500px; display:inline-block; font-size:40px; background-color:transparent; color: #CCC"><i class="fa fa-spinner fa-spin"></i>  ' + str + '</div></div>', // can be a HTML string, jQuery object, or CSS selector
    type: 'inline'
  }
}); 	}

    else $.magnificPopup.close();
	}

	
function mytooltip(kz, message){
		
       var valuez = '<div id="tooltip_' + kz + '" style=" position:relative; border: thin dotted #FFC; width:auto; padding: 5px; border-radius: 4px;" role="tooltip"><div style="position:absolute;width:0;height:0;border-color:transparent;border-style:solid; top:0;left:50%; margin-bottom: 10px; margin-left:-5px;border-width:5px 5px 5px 5px;border-top-color:#F50"></div><div style="background-color: transparent; color:#F00; font-size:12px; font-family:\'Times New Roman\', Times, serif; text-align:left">' + message + '</div></div>';
       $("#" + kz).after(valuez);
		//$("#" + kz).tooltip('show');
     		$("#" + kz).focus(); 
			
					setTimeout(function(){$("#tooltip_" + kz).remove(); },10000);
		
		}







function password_change_form(event){
		
		event.preventDefault() //Prevent default form submission, we are using ajax to submit user details
	
	var token = $('#token').val();
	var pword1 = $('#pword1').val().trim();
	var pword2 = $('#pword2').val().trim();
	
	if(pwdmatch_2() == 0){  //check if password match with the pwdmatch() function
			 return;
			}
			
	
	var post_data = 'token=' + token + '&pword=' + encodeURIComponent(pword1);
	
var sbutton = $("#sbutton").html(); //grab the initial content
$("#sbutton").html('<span class="fa fa-spin fa-spinner fa-2x"></span> please wait...');

$('#recovery_report').html('');
	
	//Ajax request to post registration details
	$.ajax({
	 type: "POST",
	 url:   "./password_recovery.php",
	 data: post_data,
	 success: function(data){ //console.log(data);
	      $("#sbutton").html(sbutton);
		  if(data == 'PASS'){//registration was successful
			$('#recovery_report').html('<div style="padding:20px; background-color:#FFF; color:#0C0">Password changed successfully.  <a href="./" style="color:#090">Proceed to login</a> </div>');
			$('#pword1').val('');
			$('#pword2').val(''); 
			  }
		  else { //registration not successful
		     $('#recovery_report').html(data);
			  }
	 }
   });
		
}

function pwdmatch_2(){
   
   //function to check if password match or contain username

  var ptest = (document.getElementById("pword1").value).trim();
  var ptest2 = (document.getElementById("pword2").value).trim();
  var username = (document.getElementById("username").value).trim();
  
  if(username == '') username = 'abcd123';
  
             if(ptest.length < 6){mytooltip("pword1", "Passsword is too short"); return 0; }
		   
		      if(ptest != ptest2 ){mytooltip("pword2", "Passsword not match");  return 0; }
			  if(ptest.indexOf(username) !== -1  || username.indexOf(ptest) !== -1){mytooltip("pword1", "password look unsecure. It should be different from your username"); return 0; }
       return 1;
	
	}




function setCookie(cname, cvalue, exdays) {
  var d = new Date();
  d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
  var expires = "expires="+d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}