// JavaScript Document

var table = null;

var global_ch_dir = '';

  
var table = $('#myTable').DataTable( {
	"processing": true,
	"serverSide": true,
   "ajax": "./connect/category.php?ch=get_cats",
   "bSortCellsTop" : true,
   "rowId" : "0",
   dom: '<B<"datatable_dom_pull_left"f><"pull-right"l>r<t>lip>',
	'initComplete' : function(setting, json){ //When table has been fully initialize
	},
	//responsive: true,
	'lengthMenu': [[50, 100, 200, 500, 2000, -1], [50, 100, 200, 500, 2000, 'All']],
    columns: [
        { data: null, searchable: false, sortable: false, render: function(data, type, row, meta){ return (meta.row + meta.settings._iDisplayStart + 1);}},
		{ data: 1},
		{data: 2},
		{ data: null, searchable: false, className: "editor_btn",  sortable: false,  render: function(data, type, row, meta){  return '<button class="btn btn-sm btn-primary" onclick="edit_row(event)"><span class="fa fa-edit"></span> Edit </button> | <button onclick="remove_entry(event, 0)" class="btn btn-sm btn-danger"><span class="fa fa-trash-o"></span> Delete</button>'}},
        // etc
    ], 
	
	"order" : [[1, "asc"]],
	//select: true,
	buttons: [
	    {
                text: 'New',
                action: function () {
                   create_row();
                }
        },
		'csv',
		'colvis'
		
    ]
} );


$('#myTable thead tr:eq(1) th').each( function (i) {
         if($(this).hasClass('sch')){
		 $(this).html('<input style="min-width:200px" type="text" placeholder="search"/>')
		 $('input', this).on('keyup change', function(){
            if ( table.column((i)).search() !== this.value ) {
			    table
                    .column((i))
                    .search( this.value)
                    .draw();
            }
        } );
		
    } 
	
	else if($(this).hasClass('sch_sel')){
			  $('select', this).on('change', function(){
				if ( table.column(i).search() !== this.value ) {
					
					table
						.column(i)
						.search( this.value )
						.draw();
				}
			} );
		 }

});



function create_row(){
	
	$("#modal_entry form").trigger('reset');
	
	global_ch_dir = 'create_cat';
	
	$('#modal_entry .modal-header h4').html('New  Category');
	$('#modal_entry .modal-footer button:eq(1)').html('<span class="fa fa-plus"></span> Create');
	
	$('#modal_entry').modal('show');

	$("#errmsg").html('');
}


function edit_row(event){

	event.preventDefault();

	$("#modal_entry form").trigger('reset');
	
	$("#type").closest('div').hide();

	var parent = $(event.target).closest('tr');
	var rdata = table.row(parent).data();
	
	$("#entry_id").val(rdata[0]); 
	
	$("#name").val(rdata[1]);
	
	
	global_ch_dir = 'edit_cat';
	
	$('#modal_entry .modal-header h4').html('Update Category');
	$('#modal_entry .modal-footer button:eq(1)').html('<span class="fa fa-save"></span> Update');
	
	$('#modal_entry').modal('show');
	$("#errmsg").html('');
}




function update_entry(event){
	
	event.preventDefault();
	
	let name = $("#name").val().trim();
	let e_id =  $("#entry_id").val();

	let fdata = {ch: global_ch_dir, e_id,  name};

	let sbutton = $("#sbutton").html(); //grab the initial content
	$("#errmsg").html('');
	$("#sbutton").html('<span class="fa fa-spin fa-spinner fa-2x"></span> Submitting...');
   
   $.ajax({
	 type: "POST",
	 url:   "./connect/category.php",
	 data: fdata,
	 success: function(data){
		     data = data.trim();
			 $("#sbutton").html(sbutton);
			
			 if(data.substr(0, 4) == "PASS"){
				 
				 var e_id = data.substr(4);
				
				 if(global_ch_dir == 'edit_cat'){
					 var table_row = "#myTable  #" + e_id;
					 let bdata = table.row(table_row).data();
					 table.row(table_row).data([e_id, name, bdata[2]]).invalidate();
					 $("#modal_entry form").trigger('reset');
					 $("#errmsg").html('<div style="font-size:16px; color:#092; font-weight: bold" class="text-success">Updating entry was successful</div>');
					 		 
				 }
				 else{
					 var rowNode = table.row.add([e_id, name, 0]).draw().node();
					 $(rowNode).css('color', 'green').animate({color: 'black'});
				 }
				 $('#modal_entry').modal('hide');
				 
			 }
			 else{
			   $("#errmsg").html('<span class="text-danger">' +data + '</span>');
			   //myalert('<span class="text-danger">' +data + '</span>');
				
			  }
		    },
		  });
	
}


//ALTER TABLE `parts` ADD `brand` VARCHAR(100) NULL DEFAULT NULL AFTER `id`, ADD `notes` VARCHAR(150) NULL DEFAULT NULL AFTER `brand`; 

 
 function remove_entry(event, np){
	    
	   if(np == 0){
		 event.preventDefault();
		 glob_entry_id = $(event.target).closest('tr').prop('id');
		 $("#modal_delete .modal-body").html('Do you want to remove this Category? <br><br><b>Note:</b> You might have to delete projects with this category name first or update their category before this action'); 
		 $("#modal_delete .delete_action_btn")[0].setAttribute('onClick', 'remove_entry(event, 1)');
		 $("#modal_delete .delete_action_btn").removeClass('btn-success');
		 $("#modal_delete .delete_action_btn").addClass('btn-danger');
		 $("#modal_delete .delete_action_btn").html('<span class="fa fa-trash-o"></span>  REMOVE');
		 $("#modal_delete").modal('show');  
		 
		 $("#delete_conf_code").html(random_string(4));
		 $("#delete_conf_code_val").val('');

		   
		   }

	  else{

		if($("#delete_conf_code").html() != $("#delete_conf_code_val").val()){
			alert('wrong code provided.'); return;
		}

	
	   fdata = {ch: 'remove_cat', id: glob_entry_id};
	   
	   var sbutton = $('#myTable  #'+ glob_entry_id + ' .editor_btn').html();
	   
	   $('#myTable  #'+ glob_entry_id +' .editor_btn').html('<span class="fa fa-spin fa-spinner"></span>')
			
		 $.ajax({
		 type: "POST",
		 url:  "./connect/category.php",
		 data: fdata,
		 success: function(data){  console.log(data);
		 		data = data.trim();	
				 $("#modal_delete .delete_action_btn").html('Delete');
				 if(data.substr(0,4) == 'PASS'){
					
					$('#myTable  #'+ glob_entry_id).remove();
					 
					}
				   else{
					   $('#myTable  #'+ glob_entry_id + ' .editor_btn').html(sbutton)
					   alert(data);
					   
					   }
					
				},
			  });	
		}
}



function random_string(length) {
	var result           = '';
	var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	var charactersLength = characters.length;
	for ( var i = 0; i < length; i++ ) {
	  result += characters.charAt(Math.floor(Math.random() * 
  charactersLength));
   }
   return result;
  }
  