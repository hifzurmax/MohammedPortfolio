<?php 
session_start();
//date_default_timezone_set("Africa/Lagos");
   if(!isset($_SESSION['admina'])) die(header("Location: ./"));

require '../scripts/config.php';	

if($_SESSION['role'] == '2') $kzn =  1; else {
die('auttentication error. Please login');	
}

$pdo = new mypdo();

?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Categories</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="css/fontastic.css">
    <!-- Google fonts - Roboto -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
    <!-- Custom Scrollbar-->
    <link rel="stylesheet" href="vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/select2.min.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="../images/favicon.png">
    <meta name="msapplication-TileColor" content="#21d900;">
    <meta name="theme-color" content="#21d900;">
    
    
    
    <link rel="stylesheet" type="text/css" href="css/datatables.min.css" />
    <link rel="stylesheet" type="text/css" href="css/buttons.dataTables.min.css" />
    <link rel="stylesheet" type="text/css" href="css/dataTables.fontAwesome.css" />
    

  
  </head>
  <body>
    
    <?php  require("templates/header.php"); ?>  
    
       <!-- Breadcrumb-->
      <div class="breadcrumb-holder">
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="./">Home</a></li>
            <li class="breadcrumb-item active">Project Categories</li>
          </ul>
        </div>
      </div>
      
      
   <!-- Item Section -->
     <section>
     <div class="container-fluid my_list_cod" style="">
     
     
     <div class="table-responsive">
          <table id="myTable" class="table table-striped table-bordered">
        <thead>
             <tr>
            	<th></th>
                <th>Name</th>
                <th>Count</th>
                <th></th>
             </tr>
             <tr>
               
            	<th class=""></th>
                <th class="sch"></th>
                <th class=""></th>
                <th></th>
             </tr>
        </thead>
        </table>
       
       </div>
     
     
     
       </div>
    </section>
  
  
  
  
  
              
      <footer class="main-footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-6">
              
            </div>
            <div class="col-sm-6 text-right">
              <p> <span class="fa fa-star"></span> <a href="" class="external"><small>ADMIN</small></a></p>
              <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions and it helps me to run Bootstrapious. Thank you for understanding :)-->
            </div>
          </div>
        </div>
      </footer>
    </div>
    


  <div class="modal" id="modal_entry">
	<form action=""  id="update_profile" onsubmit="update_entry(event)">
  	<div class="modal-dialog">
    <div class="modal-content" style="">
     <div class="modal-header">
    	<h4>Update Entry</h4>
        <div style="text-align:right"> <button  data-dismiss="modal" type="button" class="close">&times;</button></div>
      </div>
 <!-- Modal body -->
      <div class="modal-body" style="font-size:14px;">
      <div class="row">
              <input id="entry_id" name="e_id" type="hidden">
            <div class="col-12 form-group">
            	<label>Name </label>
                <input id="name" maxlength="60" name="name" required class="form-control" >
            </div>
      </div>
        
      <p id="errmsg"></p>  
      </div>
 <!-- Modal footer -->
      <div class="modal-footer" id="sbutton">    
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button  class="btn btn-primary" style="font-weight:bold" type="submit"> Update</button>
      </div>

    </div>
  </div>
  </form>
</div>


        
  <!--  Modal  ALert -->
<div class="modal" id="modal_delete">
  <div class="modal-dialog">
    <div class="modal-content">
    <div style="text-align:right"> <button type="button" class="close" data-dismiss="modal">&times;</button></div>
 <!-- Modal body -->
      <div class="modal-body alert alert-warning" style="font-size:16px; color:#000">
        Do you want to delete this project?
      </div>
      
        <div style="margin: 10px 20px; font-size:14px;" class="alert alert-warning">
          <div >Please enter code in box below to confirm this action</div>
          <div>code: <b id="delete_conf_code" style="margin-left:20px;">390904</b></div>
          <div><input onpaste="event.preventDefault()" id="delete_conf_code_val" style="width:200px; height:35px; padding-left:10px;"></div>
        </div>

 <!-- Modal footer -->
      <div style="border-top:1px solid #777; padding:20px 10px;">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn  pull-right delete_action_btn" data-dismiss="modal">Delete</button>
      </div>

    </div>
  </div>
</div>

    
    <!--  Modal  ALert -->
<div class="modal" id="modal_alert">
  <div class="modal-dialog">
    <div class="modal-content">
    <div style="text-align:right"> <button type="button" class="close" data-dismiss="modal">&times;</button></div>
 <!-- Modal body -->
      <div class="modal-body" style="font-size:14px;">
        Modal body..
      </div>
 <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

    
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    
    
    <!-- Main File-->
   
    <script> var glob_table = "word"; </script>
     
     <script src="js/datatables.min.js"></script>
    <script src="js/dataTables.buttons.min.js"></script>
    <script src="js/buttons.html5.min.js"></script>
    <script src="js/buttons.colVis.min.js"></script>
    <script src="js/categories.js"></script>
    
    
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <script src="vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/front.js"></script>

 
  </body>
</html>

