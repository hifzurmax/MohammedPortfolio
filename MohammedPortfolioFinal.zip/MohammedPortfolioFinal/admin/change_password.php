<?php 
session_start();
   //date_default_timezone_set("Africa/Lagos");
      if(!isset($_SESSION['admina'])) die(header("Location: ./"));



require '../scripts/config.php';

 ?> 




<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> ADMIN | Change Password</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css?version=<?php echo glob_version; ?>">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css?version=<?php echo glob_version; ?>">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="css/fontastic.css?version=<?php echo glob_version; ?>">
    <!-- Google fonts - Roboto -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
    <!-- Custom Scrollbar-->
    <link rel="stylesheet" href="vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.css?version=<?php echo glob_version; ?>">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css?version=<?php echo glob_version; ?>">
    
    <link rel="stylesheet" href="css/magnific-popup.css?version=<?php echo glob_version; ?>">
    <!-- Favicon-->
    <link rel="shortcut icon" href="../images/favicon.png">
    <meta name="msapplication-TileColor" content="#21d900;">
    <meta name="theme-color" content="#21d900;">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js?version=<?php echo glob_version; ?>"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js?version=<?php echo glob_version; ?>"></script><![endif]-->
  
  
  </head>
  <body>
    
    <?php  require("templates/header.php"); ?>  
    
       <!-- Breadcrumb-->
      <div class="breadcrumb-holder">
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="./">Home</a></li>
            <li class="breadcrumb-item active"> Change Password     </li>
          </ul>
        </div>
      </div>
      
      
   <!-- Item Section -->
     <section>
     <div class="container-fluid" style="text-align:center">
        <div class="modal-body pf_password" style="display:inline-block; max-width:500px; width:95%; background-color:#FFF; padding:20px; border-radius:10px; box-shadow:2px 2px 2px #C0C0C0; text-align:left">
            <div class="row">
              <div class="col-12">
                 
                <form action="#" id="password_form" onSubmit="update_password(event, 'password')" method="post">
                 <div class="errmsg" style=" margin: 20px;"></div>
                  
                  <div class="row" style="max-width:400px;">
                    <div class="col-12 form-group">
                      <label for="m_password">Enter Old Password </label>
                      <input type="password" required minlength="6" maxlength="50" class="form-control" id="m_password" name="m_password">
                    </div>
                    <div class="col-12 form-group">
                      <label for="m_password">New Password </label>
                      <input type="password" required minlength="6" maxlength="50" class="form-control" id="m_password" name="m_password_1">
                    </div>
                    <div class="col-12 form-group">
                      <label for="m_password">Retype New Password </label>
                      <input type="password" required minlength="6" maxlength="50" class="form-control" id="m_password" name="m_password_2">
                    </div>
                  </div>
                  
                  <div class="row"  style="max-width:400px; padding:40px 10px;">
                    <input type="hidden" name="password" value="sup">
                    <div class="col-md-12 text-center msbutton">
                      <input type="submit" class="btn btn-primary" value="Update">
                    </div>
                  </div>
                  
                </form>
              </div>
            </div>
            
          </div>
              
      </div>         
     </section>
  
  
  
  
  
              
      <footer class="main-footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-6">
              
            </div>
            <div class="col-sm-6 text-right">
              <p> <span class="fa fa-star"></span> <a href="" class="external"><small>ADMIN</small></a></p>
              <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions and it helps me to run Bootstrapious. Thank you for understanding :)-->
            </div>
          </div>
        </div>
      </footer>
    </div>
    
    
    <!--  Modal  ALert -->
<div class="modal" id="modal_alert">
  <div class="modal-dialog">
    <div class="modal-content">
    <div style="text-align:right"> <button type="button" class="close" data-dismiss="modal">&times;</button></div>
 <!-- Modal body -->
      <div class="modal-body" style="font-size:14px;">
        Modal body..
      </div>
 <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

            <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js?version=<?php echo glob_version; ?>"></script>
    <script src="vendor/popper.js/umd/popper.min.js?version=<?php echo glob_version; ?>"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js?version=<?php echo glob_version; ?>"></script>
    <script src="js/grasp_mobile_progress_circle-1.0.0.min.js?version=<?php echo glob_version; ?>"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js?version=<?php echo glob_version; ?>"> </script>
    <script src="vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js?version=<?php echo glob_version; ?>"></script>
    <!-- Main File-->
    <script src="js/front.js?version=<?php echo glob_version; ?>"></script>
    <script src="js/magnificent_popup.js?version=<?php echo glob_version; ?>"></script>
     <script src="js/admin.js?version=<?php echo glob_version; ?>"></script>
  
 
  </body>
</html>
