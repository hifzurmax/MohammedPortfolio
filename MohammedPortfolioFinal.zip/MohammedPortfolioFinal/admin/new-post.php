<?php
session_start();
//date_default_timezone_set("Africa/Lagos");
if (!isset($_SESSION['admina'])) die(header("Location: ./"));



require '../scripts/config.php';

$uid = $_SESSION['admina'];

$pdo = new mypdo();


?>


<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Create new blog post</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="all,follow">
	<!-- Bootstrap CSS-->
	<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css?version=<?php echo glob_version; ?>">
	<!-- Font Awesome CSS-->
	<link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css?version=<?php echo glob_version; ?>">
	<!-- Fontastic Custom icon font-->
	<link rel="stylesheet" href="css/fontastic.css?version=<?php echo glob_version; ?>">
	<!-- Google fonts - Roboto -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
	<!-- Custom Scrollbar-->
	<link rel="stylesheet" href="vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.css?version=<?php echo glob_version; ?>">
	<!-- theme stylesheet-->
	<link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
	<link rel="stylesheet" href="css/magnific-popup.css">
	<!-- Custom stylesheet - for your changes-->
	<link rel="stylesheet" href="css/custom.css?version=<?php echo glob_version; ?>">
	<link rel="stylesheet" href="css/create_survey.css?version=<?php echo glob_version; ?>">

	<script src="ckeditor/ckeditor.js"></script>
	<link rel="ckeditor/stylesheet" href="toolbarconfigurator/lib/codemirror/neo.css">

	<!-- Favicon-->
	<link rel="shortcut icon" href="../images/favicon.png">
	<meta name="msapplication-TileColor" content="#21d900;">
	<meta name="theme-color" content="#21d900;">
	<script src="ckeditor/ckeditor.js"></script>
	<link rel="ckeditor/stylesheet" href="toolbarconfigurator/lib/codemirror/neo.css">

</head>

<body>

	<?php require("templates/header.php"); ?>

	<!-- Breadcrumb-->
	<div class="breadcrumb-holder">
		<div class="container-fluid">
			<ul class="breadcrumb">
				<li class="breadcrumb-item"><a href="blog.php">Blog</a></li>
				<li class="breadcrumb-item active">New Post</li>
			</ul>
		</div>
	</div>

	<form action="" method="post" onSubmit="submit_form(event)">
		<!-- Item Section -->
		<section id="" style="background-color:aquamarine">
			<div class="container" style="text-align:center">
				<div style="max-width:1000px; width:100%; display:inline-block; text-align:left">
					<div class="card" style="margin-top:30px; border-radius:10px;">
						<div class="card-body">

							<div class="form-group" style="">
								<label>Title</label>
								<input class="form-control" name="title" id="title" required minlength="5" maxlength="200">
							</div>
							<div class="form-group" style="">
								<label>Meta Description</label>
								<input class="form-control" name="meta" id="meta" required maxlength="500">
							</div>
							<div class="form-group" style="">
								<label>Keywords</label>
								<input class="form-control" name="keywords" id="keywords" maxlength="500">
							</div>
							<div class="form-group" style="">
								<label>Description</label>
								<textarea class="form-control" id="desc_n" name="desc_n"></textarea>
							</div>

						</div>
					</div>
				</div>
			</div>
		</section>


		<div id="sbutton" style="margin-top:40px; margin-bottom:50px; text-align:center">
			<button class="btn btn-primary" style="min-width:150px; border-radius:5px;" type="submit"> Submit </button>
		</div>

	</form>





	<footer class="main-footer">
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-6">
					
				</div>
				<div class="col-sm-6 text-right">
					<p> <span class="fa fa-star"></span> <a href="" class="external"><small>ADMIN</small></a></p>
					<!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions and it helps me to run Bootstrapious. Thank you for understanding :)-->
				</div>
			</div>
		</div>
	</footer>
	</div>


	<!--  Modal  ALert -->
	<div class="modal" id="modal_alert">
		<div class="modal-dialog">
			<div class="modal-content">
				<div style="text-align:right"> <button type="button" class="close" data-dismiss="modal">&times;</button></div>
				<!-- Modal body -->
				<div class="modal-body" style="font-size:14px;">
					Modal body..
				</div>
				<!-- Modal footer -->
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>

			</div>
		</div>
	</div>


	<!-- JavaScript files-->
	<script src="vendor/jquery/jquery.min.js?version=<?php echo glob_version; ?>"></script>
	<script src="vendor/popper.js/umd/popper.min.js?version=<?php echo glob_version; ?>"> </script>
	<script src="vendor/bootstrap/js/bootstrap.min.js?version=<?php echo glob_version; ?>"></script>

	<!-- Main File-->

	<script src="js/select2.min.js?version=<?php echo glob_version; ?>"></script>
	<script src="js/magnificent_popup.js?version=<?php echo glob_version; ?>"></script>
	<script src="js/main.js?version=<?php echo glob_version; ?>"></script>

	<script src="js/post.js?version=<?php echo glob_version; ?>"></script>

	<script src="vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js?version=<?php echo glob_version; ?>"></script>
	<script src="js/front.js?version=<?php echo glob_version; ?>"></script>

</body>

</html>