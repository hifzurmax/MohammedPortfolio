<!-- Side Navbar -->
<nav class="side-navbar">
  <div class="side-navbar-wrapper">
    <!-- Sidebar Header    -->
    <div class="sidenav-header d-flex align-items-center justify-content-center">
      <!-- Small Brand information, appears on minimized sidebar-->
      <div class="sidenav-header-log" style=" text-align:left"><a style="width:100%; background-color:transparent" href="../" class="brand text-center"><img src="../img/logo.webp" style="width:95%; max-height:40px; border-radius:0px" /></a></div>
    </div>
    <!-- Sidebar Navigation Menus-->
    <div class="main-menu">
      <h5 class="sidenav-heading">Main</h5>
      <ul id="side-main-menu" class="side-menu list-unstyled">
        <li><a href="./"> <i class="fa fa-home"></i> Home</a></li>
        <li><a href="contacts.php"><i class="fa fa-address-card"></i> Contact Messages</a></li>
        <li><a href="blog.php"><i class="fa fa-book"></i> Blog Posts</a></li>
        <li><a href="projects.php"><i class="fa fa-briefcase"></i> Projects</a></li>
        <li><a href="categories.php"><i class="fa fa-tree"></i> Categories</a></li>
      </ul>
      <h5 class="sidenav-heading">Others</h5>
      <ul  class="side-menu list-unstyled">
        <?php if ($_SESSION['role'] == 2) { ?>
          <li><a href="admins.php"> <i class="fa fa-user-secret"></i> Admins </a></li>
        <?php } ?>
        <li><a href="change_password.php"> <i class="fa fa-lock"></i>Change Password </a></li>
        <li style="margin-top:30px;"><a href="./login.php?logout=1"> <i class="fa fa-signout"></i> Logout </a></li>
      </ul>
    </div>
  </div>
</nav>
<div class="page">
  <!-- navbar-->
  <header class="header">
    <nav class="navbar">
      <div class="container-fluid">
        <div class="navbar-holder d-flex align-items-center justify-content-between">
          <div class="navbar-header"><a style="background-color:#0C0; font-size:16px;" id="toggle-btn" href="#" class="menu-btn"><i class=" fa fa-bars"> </i></a><a href="#" class="navbar-brand">
              <div class="brand-text d-none d-md-inline-block"></div>
            </a></div>
          <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">
            <!-- Notifications dropdown-->





            <!-- Log out-->
            <li class="nav-item dropdown"><a id="languages" rel="nofollow" data-target="#" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link language dropdown-toggle"><span class="fa fa-user-o"></span><span class="d-none d-sm-inline-block"><?php echo $_SESSION['email']; ?></span></a>
              <ul aria-labelledby="languages" class="dropdown-menu">
                <li><a rel="nofollow" href="./login.php?logout=1" class="dropdown-item"> <span class=" fa fa-sign-out"></span> <span>Logout</span></a></li>

              </ul>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </header>