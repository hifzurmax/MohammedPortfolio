<?php
session_start();
if(!isset($_SESSION['admina'])) die("Please login");


require '../../scripts/config.php';	

$uid = $_SESSION['admina'];

$pdo = new mypdo();



if(isset($_POST['ch']) && $_POST['ch'] == "new_post"){

	
	$title = plain_validate($_POST['title']);
	$keywords = plain_validate($_POST['keywords']);
	$meta = plain_validate($_POST['meta']);
	$content = $_POST['desc_n'];
	$title_url = seoUrl($title);



	$check = $pdo->get_one("SELECT * FROM posts WHERE title_url = ?", $title_url);
	if($check != null) die("This  blog title for post already exist in the database");


	$timec = time();
	
	$id = $pdo->new_post($title, $keywords,  $meta,  $content,  date("Y-m-d H:i:s"), $title_url);

	if(substr($id, 0, 6) == 'Failed'){
		//unlink($folder.$link);
		die($id);
	}
	else{

		die("success");

	}


}


if(isset($_POST['ch']) && $_POST['ch'] == "edit_post"){

	
	$id = intval($_POST['p_id']);
	$title = plain_validate($_POST['title']);
	$keywords = plain_validate($_POST['keywords']);
	$meta = plain_validate($_POST['meta']);
	$content = $_POST['desc_n'];

	$title_url = seoUrl($title);
    
	$check = $pdo->get_one("SELECT * FROM posts WHERE title_url = ? AND id != $id", $title_url);
	if($check != null) die("Thos blog title already exist in the database");

	$timec = time();
	
	$id = $pdo->update_post($id, $title, $keywords, $meta,  $content,  date("Y-m-d H:i:s"), $title_url);

	if(substr($id, 0, 6) == 'Failed'){
		unlink($folder.$link);
		die($id);
	}
	else{

		die("success");

	}


}



if(isset($_POST['ch']) && $_POST['ch'] == "delete_post"){

	
	$id = plain_validate($_POST['p_id']);

	$pdo->exec_query("DELETE FROM posts WHERE id = ?", $id);

	die("PASS");


}







if(isset($_GET['ch']) && $_GET['ch'] == "get_posts"){
		
	$table  = "posts";
	  $col_map =  array("0" => "id", "1" => "updated_at", "2" => "title", "3" => "meta", "4" => "keywords");

	$only_column = array();

	
	$is_complex = false;
	//$wheres = "category_id = ".$_GET['cat_id'];
	$primaryKey = 'id';
	$columns = array();
	foreach($col_map as $key =>$value){
		$columns[] = array( 'db' => $value,     'dt' => $key );
	}

	// SQL server connection information
	$sql_details = array(
		'user' => dbuser,
		'pass' => dbpass,
		'db'   => dbname,
		'host' => dbhost
	);


 require( 'ssp_class.php' );
 
 if($is_complex){
	echo json_encode(
		SSP::complex( $_GET, $sql_details, $table, $primaryKey, $columns, $whereAll = null, $wheres)
		);	 
	 
 }
 else{
 
	echo json_encode(
		SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns)
	);
 }
 




}

