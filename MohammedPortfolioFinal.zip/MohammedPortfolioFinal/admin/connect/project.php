<?php
session_start();
if(!isset($_SESSION['admina'])) die("Please login");


require '../../scripts/config.php';	

$uid = $_SESSION['admina'];

$pdo = new mypdo();



if(isset($_POST['ch']) && $_POST['ch'] == "new_project"){

	
	$title = plain_validate($_POST['title']);
	$keywords = plain_validate($_POST['keywords']);
	$meta = plain_validate($_POST['meta']);
	$content = $_POST['desc_n'];
	$cat_id = plain_validate($_POST['cat_id']);
	$title_url = seoUrl($title);


	$formate = array('png', 'jpg', 'jpeg', 'gif');
	$img = $_FILES['image'];
	$ext = pathinfo($img['name'], PATHINFO_EXTENSION);
	$ext = strtolower($ext);
	if (!in_array($ext, $formate)) die('Uploaded file type not supported. Please upload png, jpg, jpeg');


	$check = $pdo->get_one("SELECT * FROM projects WHERE title_url = ?", $title_url);
	if($check != null) die("This  title for project already exist in the database");

	$timec = time();
	
	$id = $pdo->new_project($title, $keywords,  $meta,  $content,  date("Y-m-d H:i:s"), $title_url, $cat_id);

	if(substr($id, 0, 6) == 'Failed'){
		//unlink($folder.$link);
		die($id);
	}
	else{

		// Upload image
		@move_uploaded_file($img['tmp_name'], "../../assets/img/portfolio/".$title_url.'.'.$ext);
		$pdo->exec_query("UPDATE projects SET image = ? WHERE id = '$id'", $title_url.'.'.$ext);

		die("success");

	}


}


if(isset($_POST['ch']) && $_POST['ch'] == "edit_project"){

	
	$id = intval($_POST['p_id']);
	$title = plain_validate($_POST['title']);
	$keywords = plain_validate($_POST['keywords']);
	$meta = plain_validate($_POST['meta']);
	$cat_id = plain_validate($_POST['cat_id']);
	$content = $_POST['desc_n'];

	$title_url = seoUrl($title);
    
	$check = $pdo->get_one("SELECT * FROM projects WHERE title_url = ? AND id != $id", $title_url);
	if($check != null) die("This project title already exist in the database");

	$timec = time();

	$bproject = $pdo->get_one("SELECT * FROM projects WHERE  id = $id");
	
	$pdo->update_project($id, $title, $keywords, $meta,  $content,  date("Y-m-d H:i:s"), $title_url, $cat_id);

	if(substr($id, 0, 6) == 'Failed'){
		die($id);
	}
	else{

		if(isset($_FILES['image']) && $_FILES['image']['size'] > 50){
			$formate = array('png', 'jpg', 'jpeg', 'gif');
			$img = $_FILES['image'];
			$ext = pathinfo($img['name'], PATHINFO_EXTENSION);
			$ext = strtolower($ext);
			if (in_array($ext, $formate)){

				@unlink("../../assets/img/portfolio/".$bproject['image']);
				@move_uploaded_file($img['tmp_name'], "../../assets/img/portfolio/".$title_url.'.'.$ext);
				$pdo->exec_query("UPDATE projects SET image = ? WHERE id = '$id'", $title_url.'.'.$ext);

			}
		
		}
	
		die("success");

	}


}



if(isset($_POST['ch']) && $_POST['ch'] == "delete_project"){

	
	$id = plain_validate($_POST['p_id']);
	$bproject = $pdo->get_one("SELECT * FROM projects WHERE  id = $id");

	@unlink("../../assets/img/portfolio/".$bproject['image']);
	

	$pdo->exec_query("DELETE FROM projects WHERE id = ?", $id);

	die("PASS");


}






if(isset($_GET['ch']) && $_GET['ch'] == "get_projects"){
		
	$table  = "projects";
	  $col_map =  array("0" => "id", "1" => "updated_at", "2" => "title", "3" => "meta", "4" => "keywords", "5" => "cat_id", "6" => "image");

	$only_column = array();

	
	$is_complex = false;
	//$wheres = "category_id = ".$_GET['cat_id'];
	$primaryKey = 'id';
	$columns = array();
	foreach($col_map as $key =>$value){
		$columns[] = array( 'db' => $value,     'dt' => $key );
	}

	// SQL server connection information
	$sql_details = array(
		'user' => dbuser,
		'pass' => dbpass,
		'db'   => dbname,
		'host' => dbhost
	);


 require( 'ssp_class.php' );
 
 if($is_complex){
	echo json_encode(
		SSP::complex( $_GET, $sql_details, $table, $primaryKey, $columns, $whereAll = null, $wheres)
		);	 
	 
 }
 else{
 
	echo json_encode(
		SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns)
	);
 }
 




}

