<?php

require_once('../../scripts/config.php');

 

//*/

  
 $pdo = new mypdo();
	 
 if(isset($_GET["search"])){
       header("Content-type: application/json");
       $term = trim($_GET["search"]);
	   $pagen = $_GET["page"] - 1;
	   die($pdo->get_users('%'.$term.'%', $pagen));
	
  
  }
  
	


 class mypdo{
	 public $pdc = null;
	 public function __construct(){
		 $host = dbhost;
		 $db   =  dbname;
		 $user  =  dbuser;
		 $pass  =   dbpass;
		 $charset = 'utf8mb4';
		 $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
		 $opt = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false,];
		 $this->pdc = new PDO($dsn, $user, $pass, $opt);
		 }
	 
	 public function get_users($term, $pagen){
	
		 $qry = "SELECT * FROM users LIMIT ?, 20";
		 $stmt = $this->pdc->prepare($qry);
		// $stmt->bindParam(1, $term, PDO::PARAM_STR);
		// $stmt->bindParam(2, $term, PDO::PARAM_STR);
		 $stmt->bindParam(1, $pagen, PDO::PARAM_INT);
		 $stmt->execute();
		 $data = $stmt->fetchAll();
         return json_encode($data);
	
	 
	 }
	 
	 
	 
	
 
 }
	 