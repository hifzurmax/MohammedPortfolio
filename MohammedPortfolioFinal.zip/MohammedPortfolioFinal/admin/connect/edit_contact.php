<?php
session_start(); 

session_write_close(); //prevent session locking

require '../../scripts/config.php';

if(isset($_SESSION['admina'])){
	$uid = 	$_SESSION['admina'];
	}
else{
	
	die(die(json_encode(array("error" => 'auttentication error. Please refresh browser and login'))));
	}


$uid = $_SESSION['admina'];


		 

$pdo = new mypdo();


if(isset($_POST['action']) && $_POST['action'] == 'remove'){
	
	$datan = $_POST['data'];
	$rdata = array();
	
	foreach($datan as $index => $row){
		       
		      //DELETE the ROW here
				$pdo->exec_query('DELETE FROM contacts WHERE id = ?',$index);
				
	}
	    
	$return_d = json_encode(array('data' => $rdata));
	
    die($return_d);
	
}


