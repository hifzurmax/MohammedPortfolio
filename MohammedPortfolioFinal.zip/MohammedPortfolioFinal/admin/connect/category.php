<?php
session_start(); 

require '../../scripts/config.php';	


if(isset($_SESSION['admina'])){
	$idc = 	$_SESSION['admina'];
 }
else{
			 
    die('auttentication error. Please login');
	}




$pdo = new  mypdo();



if (isset($_POST['ch']) && $_POST['ch'] == "create_cat") {

	
	$name = plain_validate(trim($_POST['name']));

	if($pdo->get_one("SELECT * FROM categories WHERE name = ?", $name) != null){
		die("A category with this name already exist");
	}
	
	$stmt = $pdo->pdc->prepare("INSERT INTO categories(name) VALUES(?)");
	$stmt->bindParam(1, $name, PDO::PARAM_STR);

	$stmt->execute();
	$cat_id = $pdo->pdc->lastInsertId();
	die("PASS" . $cat_id);

}




elseif (isset($_POST['ch']) && $_POST['ch'] == "edit_cat") {

	$name = plain_validate(trim($_POST['name']));
	
	
	$cat_id = (int)$_POST['e_id'];

	if($pdo->get_one("SELECT * FROM categories WHERE name = ? AND cat_id != '$cat_id'", $name) != null){
		die("A category with this name already exist");
	}
	$stmt = $pdo->pdc->prepare("UPDATE categories SET name = ? WHERE cat_id = '$cat_id'");
	$stmt->bindParam(1, $name, PDO::PARAM_STR);
	$stmt->execute();

	die("PASS" . $cat_id);

}


elseif (isset($_POST['ch']) && $_POST['ch'] == "remove_cat") {

	
	$cat_id = (int)$_POST['id'];

	
	$stmt = $pdo->pdc->prepare("DELETE FROM categories  WHERE cat_id = '$cat_id'");
	$stmt->execute();
	
	die('PASS');

}


elseif (isset($_GET['ch']) && $_GET['ch'] == "get_cats") {


	$is_complex = false;
	$table = "(SELECT a.*, b.cnt FROM categories a LEFT JOIN (SELECT cat_id, COUNT(*) AS cnt FROM projects GROUP BY cat_id) b ON a.cat_id = b.cat_id ) tmp";
	$primaryKey = 'cat_id';
	$columns = array(
		array( 'db' => 'cat_id', 'dt' => 0 ),
		array( 'db' => 'name',     'dt' => 1 ),
		array( 'db' => 'cnt',     'dt' => 2 ),
		
	);
	
	
	 
	// SQL server connection information
	$sql_details = array(
		'user' => dbuser,
		'pass' => dbpass,
		'db'   => dbname,
		'host' => dbhost
	);
	 
	 
	/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * If you just want to use the basic configuration for DataTables with PHP
	 * server-side, there is no need to edit below this line.
	 */
	require( 'ssp_class.php' );

	if($is_complex){
		echo json_encode(
			SSP::complex( $_GET, $sql_details, $table, $primaryKey, $columns, null, $wheres)
		);
	}else{ 
		echo json_encode(
			SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns)
		);
	}	 
	die();
}





