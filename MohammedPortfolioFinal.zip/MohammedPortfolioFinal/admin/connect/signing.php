<?php
//session_start(); 



require '../../scripts/config.php';

///##################################################
/////      SIGN IN
///####################################################

if (isset($_POST['ch']) && $_POST['ch'] == 'sign_in') {
	$errMsg = '';

	$email = $_POST['email'];
	$password = $_POST['password'];

	if (strlen($email) < 3)
		$errMsg = 'Enter username<br>';
	if (strlen($password) < 3)
		$errMsg = 'Enter password<br>';

	if ($errMsg != '') {
		die($errMsg);
	}

	$pdo = new mypdo();
	$profn = $pdo->get_one("SELECT * FROM admins WHERE email = ?",   $email);

	if ($profn == null) {
		die("Email password not match");
	}


	$verify = password_verify($password, $profn['password']);
	if ($verify) {

		session_start();
		
		$_SESSION['admina'] = $profn['id'];
		$_SESSION['email'] = $profn['email'];
		$_SESSION['role'] = $profn['role'];

		// $number = random_int(10000000, 99999999);
		// $_SESSION['2fa'] = $number;

		//mailler2($profn['fname'], $profn['email'], $number);

		die("success");
	} else {
		die("Email password not match");
	}
}




///##################################################
/////      SIGN IN 2
///####################################################

if (isset($_POST['ch']) && $_POST['ch'] == 'sign_in2') {
	$errMsg = '';
	
	session_start();

	
	if(isset($_SESSION['2fa'])) {
		$code = $_POST['code'];

		

		if ($_SESSION['2fa'] == $code) {

			$_SESSION['admina'] = $_SESSION['adminax'];
			$_SESSION['email'] = $_SESSION['emailx'];
			$_SESSION['role'] = $_SESSION['rolex'];

			unset($_SESSION['rolex']);
			unset($_SESSION['emailx']);
			unset($_SESSION['adminax']);
			unset($_SESSION['2fa']);

			die('success');
		} else {
			die('wrong code');
		}
	} else {
		die("Error. Login again");
	}
}


