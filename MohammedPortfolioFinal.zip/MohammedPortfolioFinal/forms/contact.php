<?php

require "../scripts/config.php";

$pdo = new mypdo();

 

 $fname = plain_validate($_POST['name']);
 $email = plain_validate($_POST['email']);
 $subject = plain_validate($_POST['subject']);
 $message = plain_validate($_POST['message']);

 if(strlen($message) < 5) die('Please enter a proper message');



 $pdo->new_contact($fname, $email, $subject, $message);

 die("OK");
 