<?php



ini_set("default-charset", "UTF-8");

//Database settings
define('dbhost', 'localhost');
define('dbuser', 'root');
define('dbpass', '');
define('dbname', 'mohammed_portfolio');

define('glob_version', '1.2a');






function  strip_linz($content){

    $content = trim($content);

	$sarray = preg_split("/\r\n|\n|\r/", $content);
       
    if(count($sarray) === 1) {
        return $content;
    }
    else {
        return $sarray[0];
    }



}



function strRemoveAccents($str)
{


	$replace = array(
        'ъ'=>'-', 'Ь'=>'-', 'Ъ'=>'-', 'ь'=>'-',
        'Ă'=>'A', 'Ą'=>'A', 'À'=>'A', 'Ã'=>'A', 'Á'=>'A', 'Æ'=>'A', 'Â'=>'A', 'Å'=>'A', 'Ä'=>'Ae',
        'Þ'=>'B',
        'Ć'=>'C', 'ץ'=>'C', 'Ç'=>'C',
        'È'=>'E', 'Ę'=>'E', 'É'=>'E', 'Ë'=>'E', 'Ê'=>'E',
        'Ğ'=>'G',
        'İ'=>'I', 'Ï'=>'I', 'Î'=>'I', 'Í'=>'I', 'Ì'=>'I',
        'Ł'=>'L',
        'Ñ'=>'N', 'Ń'=>'N',
        'Ø'=>'O', 'Ó'=>'O', 'Ò'=>'O', 'Ô'=>'O', 'Õ'=>'O', 'Ö'=>'Oe',
        'Ş'=>'S', 'Ś'=>'S', 'Ș'=>'S', 'Š'=>'S',
        'Ț'=>'T',
        'Ù'=>'U', 'Û'=>'U', 'Ú'=>'U', 'Ü'=>'Ue',
        'Ý'=>'Y',
        'Ź'=>'Z', 'Ž'=>'Z', 'Ż'=>'Z',
        'â'=>'a', 'ǎ'=>'a', 'ą'=>'a', 'á'=>'a', 'ă'=>'a', 'ã'=>'a', 'Ǎ'=>'a', 'а'=>'a', 'А'=>'a', 'å'=>'a', 'à'=>'a', 'א'=>'a', 'Ǻ'=>'a', 'Ā'=>'a', 'ǻ'=>'a', 'ā'=>'a', 'ä'=>'ae', 'æ'=>'ae', 'Ǽ'=>'ae', 'ǽ'=>'ae',
        'б'=>'b', 'ב'=>'b', 'Б'=>'b', 'þ'=>'b',
        'ĉ'=>'c', 'Ĉ'=>'c', 'Ċ'=>'c', 'ć'=>'c', 'ç'=>'c', 'ц'=>'c', 'צ'=>'c', 'ċ'=>'c', 'Ц'=>'c', 'Č'=>'c', 'č'=>'c', 'Ч'=>'ch', 'ч'=>'ch',
        'ד'=>'d', 'ď'=>'d', 'Đ'=>'d', 'Ď'=>'d', 'đ'=>'d', 'д'=>'d', 'Д'=>'D', 'ð'=>'d',
        'є'=>'e', 'ע'=>'e', 'е'=>'e', 'Е'=>'e', 'Ə'=>'e', 'ę'=>'e', 'ĕ'=>'e', 'ē'=>'e', 'Ē'=>'e', 'Ė'=>'e', 'ė'=>'e', 'ě'=>'e', 'Ě'=>'e', 'Є'=>'e', 'Ĕ'=>'e', 'ê'=>'e', 'ə'=>'e', 'è'=>'e', 'ë'=>'e', 'é'=>'e',
        'ф'=>'f', 'ƒ'=>'f', 'Ф'=>'f',
        'ġ'=>'g', 'Ģ'=>'g', 'Ġ'=>'g', 'Ĝ'=>'g', 'Г'=>'g', 'г'=>'g', 'ĝ'=>'g', 'ğ'=>'g', 'ג'=>'g', 'Ґ'=>'g', 'ґ'=>'g', 'ģ'=>'g',
        'ח'=>'h', 'ħ'=>'h', 'Х'=>'h', 'Ħ'=>'h', 'Ĥ'=>'h', 'ĥ'=>'h', 'х'=>'h', 'ה'=>'h',
        'î'=>'i', 'ï'=>'i', 'í'=>'i', 'ì'=>'i', 'į'=>'i', 'ĭ'=>'i', 'ı'=>'i', 'Ĭ'=>'i', 'И'=>'i', 'ĩ'=>'i', 'ǐ'=>'i', 'Ĩ'=>'i', 'Ǐ'=>'i', 'и'=>'i', 'Į'=>'i', 'י'=>'i', 'Ї'=>'i', 'Ī'=>'i', 'І'=>'i', 'ї'=>'i', 'і'=>'i', 'ī'=>'i', 'ĳ'=>'ij', 'Ĳ'=>'ij',
        'й'=>'j', 'Й'=>'j', 'Ĵ'=>'j', 'ĵ'=>'j', 'я'=>'ja', 'Я'=>'ja', 'Э'=>'je', 'э'=>'je', 'ё'=>'jo', 'Ё'=>'jo', 'ю'=>'ju', 'Ю'=>'ju',
        'ĸ'=>'k', 'כ'=>'k', 'Ķ'=>'k', 'К'=>'k', 'к'=>'k', 'ķ'=>'k', 'ך'=>'k',
        'Ŀ'=>'l', 'ŀ'=>'l', 'Л'=>'l', 'ł'=>'l', 'ļ'=>'l', 'ĺ'=>'l', 'Ĺ'=>'l', 'Ļ'=>'l', 'л'=>'l', 'Ľ'=>'l', 'ľ'=>'l', 'ל'=>'l',
        'מ'=>'m', 'М'=>'m', 'ם'=>'m', 'м'=>'m',
        'ñ'=>'n', 'н'=>'n', 'Ņ'=>'n', 'ן'=>'n', 'ŋ'=>'n', 'נ'=>'n', 'Н'=>'n', 'ń'=>'n', 'Ŋ'=>'n', 'ņ'=>'n', 'ŉ'=>'n', 'Ň'=>'n', 'ň'=>'n',
        'о'=>'o', 'О'=>'o', 'ő'=>'o', 'õ'=>'o', 'ô'=>'o', 'Ő'=>'o', 'ŏ'=>'o', 'Ŏ'=>'o', 'Ō'=>'o', 'ō'=>'o', 'ø'=>'o', 'ǿ'=>'o', 'ǒ'=>'o', 'ò'=>'o', 'Ǿ'=>'o', 'Ǒ'=>'o', 'ơ'=>'o', 'ó'=>'o', 'Ơ'=>'o', 'œ'=>'oe', 'Œ'=>'oe', 'ö'=>'oe',
        'פ'=>'p', 'ף'=>'p', 'п'=>'p', 'П'=>'p',
        'ק'=>'q',
        'ŕ'=>'r', 'ř'=>'r', 'Ř'=>'r', 'ŗ'=>'r', 'Ŗ'=>'r', 'ר'=>'r', 'Ŕ'=>'r', 'Р'=>'r', 'р'=>'r',
        'ș'=>'s', 'с'=>'s', 'Ŝ'=>'s', 'š'=>'s', 'ś'=>'s', 'ס'=>'s', 'ş'=>'s', 'С'=>'s', 'ŝ'=>'s', 'Щ'=>'sch', 'щ'=>'sch', 'ш'=>'sh', 'Ш'=>'sh', 'ß'=>'ss',
        'т'=>'t', 'ט'=>'t', 'ŧ'=>'t', 'ת'=>'t', 'ť'=>'t', 'ţ'=>'t', 'Ţ'=>'t', 'Т'=>'t', 'ț'=>'t', 'Ŧ'=>'t', 'Ť'=>'t', '™'=>'tm',
        'ū'=>'u', 'у'=>'u', 'Ũ'=>'u', 'ũ'=>'u', 'Ư'=>'u', 'ư'=>'u', 'Ū'=>'u', 'Ǔ'=>'u', 'ų'=>'u', 'Ų'=>'u', 'ŭ'=>'u', 'Ŭ'=>'u', 'Ů'=>'u', 'ů'=>'u', 'ű'=>'u', 'Ű'=>'u', 'Ǖ'=>'u', 'ǔ'=>'u', 'Ǜ'=>'u', 'ù'=>'u', 'ú'=>'u', 'û'=>'u', 'У'=>'u', 'ǚ'=>'u', 'ǜ'=>'u', 'Ǚ'=>'u', 'Ǘ'=>'u', 'ǖ'=>'u', 'ǘ'=>'u', 'ü'=>'ue',
        'в'=>'v', 'ו'=>'v', 'В'=>'v',
        'ש'=>'w', 'ŵ'=>'w', 'Ŵ'=>'w',
        'ы'=>'y', 'ŷ'=>'y', 'ý'=>'y', 'ÿ'=>'y', 'Ÿ'=>'y', 'Ŷ'=>'y',
        'Ы'=>'y', 'ž'=>'z', 'З'=>'z', 'з'=>'z', 'ź'=>'z', 'ז'=>'z', 'ż'=>'z', 'ſ'=>'z', 'Ж'=>'zh', 'ж'=>'zh'
    );
	$str = strtr($str, $replace);
    return iconv(mb_detect_encoding($str), 'us-ascii//TRANSLIT', $str);
}

function seoUrl($str)
{
    $str = preg_replace('#[^\\p{L}\d]+#u', '-', $str);
    $str = trim($str, '-');
    $str = strRemoveAccents($str);
    $str = strtolower($str);
    $str = preg_replace('#[^-\w]+#', '', $str);
    return preg_replace('/-{2,}/', '-', $str);;
}


//date_default_timezone_set("Africa/Lagos");


function url_txn($str){

	return preg_replace("/[^a-zA-Z0-9]{1,}/", "_", $str);

}


function strip_txn($s, $ch)
{
	
	$max_length = 100;
	if($ch == 1)
		$max_length = 50;
	if($ch == 2)
		$max_length = 50;

	if (strlen($s) > $max_length) {
		$offset = ($max_length - 3) - strlen($s);
		$s = substr($s, 0, strrpos($s, ' ', $offset)) . '...';
	}

	return $s;
}




function validate($field, $l_limit, $u_limit, $value, $extra = '')
{

	if (strlen($value) < $l_limit) {
		$GLOBALS['global_report'] .=  'Too few characters for ' . $field . ' minimum: ' . $l_limit . '<br>';
		return;
	}
	if (strlen($value) > $u_limit) {
		$GLOBALS['global_report'] .=  'Too long characters for ' . $field . ' maximum: ' . $u_limit . '<br>';
		return;
	}

	return htmlspecialchars($value,  ENT_COMPAT);
}

function plain_validate($value)
{

	return htmlspecialchars($value,  ENT_COMPAT);
}






class mypdo
{
	public $pdc = null;
	public function __construct()
	{
		$host = dbhost;
		$db   =  dbname;
		$user  =  dbuser;
		$pass  =   dbpass;
		$charset = 'utf8mb4';
		$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
		$opt = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false,];
		$this->pdc = new PDO($dsn, $user, $pass, $opt);
	}



	public function exec_query($qry, $val = '', $val2 = '')
	{

		$stmt = $this->pdc->prepare($qry);
		if ($val != '') {
			$stmt->bindParam(1, $val, PDO::PARAM_STR);
		}
		if ($val2 != '') {
			$stmt->bindParam(2, $val2, PDO::PARAM_STR);
		}
		try {
			$stmt->execute();
			return 'success';
		} catch (Exception $ex) {
			return 'error';
		}
	}


	public function get_count($qry, $val = '')
	{

		$stmt = $this->pdc->prepare($qry);
		if ($val != '') {
			$stmt->bindParam(1, $val, PDO::PARAM_STR);
		}
		$stmt->execute();

		return $stmt->fetchColumn();
	}


	public function get_one($qry, $val = '')
	{

		$stmt = $this->pdc->prepare($qry);
		if ($val != '') {
			$stmt->bindParam(1, $val, PDO::PARAM_STR);
		}
		$stmt->execute();
		if ($stmt->rowCount() > 0) return $stmt->fetch();
		else return null;
	}

	public function get_all($qry, $val = '')
	{

		$stmt = $this->pdc->prepare($qry);
		if ($val != '') {
			$stmt->bindParam(1, $val, PDO::PARAM_STR);
		}
		$stmt->execute();
		return $stmt->fetchAll();
	}


	
	public function new_contact($fname, $email, $subject, $message)
	{

		$qry = "INSERT INTO contacts (fname, email, subject, message) VALUES (?, ?, ?, ?)";
		$stmt = $this->pdc->prepare($qry);
		$stmt->bindParam(1, $fname, PDO::PARAM_STR);
		$stmt->bindParam(2, $email, PDO::PARAM_STR);
		$stmt->bindParam(3, $subject, PDO::PARAM_STR);
		$stmt->bindParam(4, $message, PDO::PARAM_STR);
		try {
			$stmt->execute();
			return $this->pdc->lastInsertId();
		} catch (Exception $ex) {
			die("Error Message not sent");
		}
	}




	public function new_post($title, $keywords,  $meta,  $content,  $date, $title_url)
	{

		$qry = "INSERT INTO posts (title, keywords, meta, content, updated_at, title_url) VALUES (?, ?, ?, ?, ?, ?)";
		$stmt = $this->pdc->prepare($qry);
		$stmt->bindParam(1, $title, PDO::PARAM_STR);
		$stmt->bindParam(2, $keywords, PDO::PARAM_STR);
		$stmt->bindParam(3, $meta, PDO::PARAM_STR);
		$stmt->bindParam(4, $content, PDO::PARAM_STR);
		$stmt->bindParam(5, $date, PDO::PARAM_STR);
		$stmt->bindParam(6, $title_url, PDO::PARAM_STR);

		try {
			$stmt->execute();
			return $this->pdc->lastInsertId();
		} catch (Exception $ex) {
			return 'Failed: ' . $ex->getMessage();
		}
	}


	public function update_post($id, $title, $keywords,  $meta, $content,  $date, $title_url)
	{

		$qry = "UPDATE posts  SET title = ?, keywords = ?, meta = ?,  content = ?, updated_at = ?, title_url = ? WHERE id = ?";
		$stmt = $this->pdc->prepare($qry);
		$stmt->bindParam(1, $title, PDO::PARAM_STR);
		$stmt->bindParam(2, $keywords, PDO::PARAM_STR);
		$stmt->bindParam(3, $meta, PDO::PARAM_STR);
		$stmt->bindParam(4, $content, PDO::PARAM_STR);
		$stmt->bindParam(5, $date, PDO::PARAM_STR);
		$stmt->bindParam(6, $title_url, PDO::PARAM_STR);
		$stmt->bindParam(7, $id, PDO::PARAM_INT);

		try {
			$stmt->execute();
			return $id;
		} catch (Exception $ex) {
			return 'Failed: ' . $ex->getMessage();
		}
	}



	public function new_project($title, $keywords,  $meta,  $content,  $date, $title_url, $cat_id)
	{

		$qry = "INSERT INTO projects (title, keywords, meta, content, updated_at, title_url, cat_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
		$stmt = $this->pdc->prepare($qry);
		$stmt->bindParam(1, $title, PDO::PARAM_STR);
		$stmt->bindParam(2, $keywords, PDO::PARAM_STR);
		$stmt->bindParam(3, $meta, PDO::PARAM_STR);
		$stmt->bindParam(4, $content, PDO::PARAM_STR);
		$stmt->bindParam(5, $date, PDO::PARAM_STR);
		$stmt->bindParam(6, $title_url, PDO::PARAM_STR);
		$stmt->bindParam(7, $cat_id, PDO::PARAM_INT);

		try {
			$stmt->execute();
			return $this->pdc->lastInsertId();
		} catch (Exception $ex) {
			return 'Failed: ' . $ex->getMessage();
		}
	}


	public function update_project($id, $title, $keywords,  $meta, $content,  $date, $title_url, $cat_id)
	{

		$qry = "UPDATE projects  SET title = ?, keywords = ?, meta = ?,  content = ?, updated_at = ?, title_url = ?, cat_id = ? WHERE id = ?";
		$stmt = $this->pdc->prepare($qry);
		$stmt->bindParam(1, $title, PDO::PARAM_STR);
		$stmt->bindParam(2, $keywords, PDO::PARAM_STR);
		$stmt->bindParam(3, $meta, PDO::PARAM_STR);
		$stmt->bindParam(4, $content, PDO::PARAM_STR);
		$stmt->bindParam(5, $date, PDO::PARAM_STR);
		$stmt->bindParam(6, $title_url, PDO::PARAM_STR);
		$stmt->bindParam(7, $cat_id, PDO::PARAM_INT);
		$stmt->bindParam(8, $id, PDO::PARAM_INT);

		try {
			$stmt->execute();
			return $id;
		} catch (Exception $ex) {
			return 'Failed: ' . $ex->getMessage();
		}
	}



	public function insert_recover($timec, $username)
	{
		$qry = "INSERT INTO recovertb (id, username) VALUES (?, ?)";
		$stmt = $this->pdc->prepare($qry);
		$stmt->bindParam(1, $timec, PDO::PARAM_INT);
		$stmt->bindParam(2, $username, PDO::PARAM_STR);
		$stmt->execute();
		if ($stmt->rowCount() < 1)
			die(json_encode(array('status' => 'error', 'message' => 'A database error occured')));
	}


	public function get_recover($timec, $username)
	{
		$qry = "SELECT username FROM recovertb WHERE id = ? AND username = ?";
		$stmt = $this->pdc->prepare($qry);
		$stmt->bindParam(1, $timec, PDO::PARAM_INT);
		$stmt->bindParam(2, $username, PDO::PARAM_STR);
		$stmt->execute();
		if ($stmt->rowCount() < 1)
			die('link has expired');
		else {
			return $stmt->fetch();
		}
	}

	public function delete_recover($timec, $username)
	{
		$qry = "DELETE FROM recovertb WHERE id = ? AND username = ?";
		$stmt = $this->pdc->prepare($qry);
		$stmt->bindParam(1, $timec, PDO::PARAM_INT);
		$stmt->bindParam(2, $username, PDO::PARAM_STR);
		$stmt->execute();
	}


	public function update_password($table, $pword, $username, $col = 'email')
	{
		$qry = "UPDATE $table SET password = ? WHERE $col = ?";
		$stmt = $this->pdc->prepare($qry);
		$stmt->bindParam(1, $pword, PDO::PARAM_STR);
		$stmt->bindParam(2, $username, PDO::PARAM_STR);
		$stmt->execute();
	}
}
